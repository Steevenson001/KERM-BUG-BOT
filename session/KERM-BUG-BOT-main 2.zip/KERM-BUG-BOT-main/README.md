## KERM-BUG-MD
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
| [![Kgtech-cmr](https://telegra.ph/file/2edd66fcb697064a82bdc.jpg)](https://github.com/Kgtech-cmr)|
|----|
   ✦𝗠𝗔𝗗𝗘 𝗕𝗬 𝐊𝐆 𝐓𝐄𝐂𝐇✦
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

<p align="center">
<a href="#"><img title="Creator" src="https://img.shields.io/badge/Creator-𝐊𝐆 𝐓𝐄𝐂𝐇-blue.svg?style=for-the-badge&logo=github"></a>
<p/>
<p align="center">
<a href="https://github.com/Kgtech-cmr"><img title="Author" src="https://img.shields.io/badge/KGTECH-black?style=for-the-badge&logo=Github"></a> <a href="https://chat.whatsapp.com/FpxvVBFOozA6IhNxIWhwFw"><img title="Author" src="https://img.shields.io/badge/CHANNEL-black?style=for-the-badge&logo=whatsapp"></a> <a href="https://wa.me/237656520674"><img title="Author" src="https://img.shields.io/badge/CHAT US-black?style=for-the-badge&logo=whatsapp">
<p/>

 <p align="center">
  <a href="https://kg-site-support.vercel.app/">
    <img src="https://img.shields.io/badge/KG WEBSITE-000?style=for-the-badge&logo=vercel&logoColor=white" alt="Generate Session ID"/>
  </a>
   
<p align="center">
<a href="https://github.com/Kgtech-cmr/KERM-BUG-BOT/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/Kgtech-cmr/KERM-BUG-BOT?color=white&style=flat-square"></a>
<a href="https://github.com/Kgtech-cmr/KERM-BUG-BOT/network/members"><img title="Forks" src="https://img.shields.io/github/forks/Kgtech-cmr/KERM-BUG-BOT?color=yellow&style=flat-square"></a>
<a href="https://github.com/Kgtech-cmr/KERM-BUG-BOT/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/Kgtech-cmr/KERM-BUG-BOT?label=Watchers&color=red&style=flat-square"></a>
   
### If you want to deploy somewhere else, upload your creds.json in session folder after getting pair code 

## SETUP FOR KERM

**CLICK HERE 👇 TO FORK**

<a href="https://github.com/Kgtech-cmr/KERM-BUG-BOT/fork"><img src="https://img.shields.io/badge/FORK-KERM-black" alt="FORK KERM-BUG-BOT" width="100"></a>

1.𝐆𝐄𝐓 𝐒𝐄𝐒𝐒𝐈𝐎𝐍 𝐈𝐃 𝐅𝐑𝐎𝐌 𝐒𝐄𝐑𝐕𝐄𝐑

<a href="https://bug-session-kerm-dnls.onrender.com"><img src="https://img.shields.io/badge/PAIR_CODE-blue" alt="Click Here to Get Pair-Code" width="110"></a>   

## How To Deploy On Panel
 [![YOUTUBE](https://img.shields.io/badge/HOW_TO_DEPLOY-red?style=for-the-badge&logo=youtube&logoColor=white)](https://youtu.be/PMKAQ3SVa4A?si=HGsxbvOiZ57jlunh)

#### DEPLOY TO RENDER 

1. Now Deploy
    <br>
<a href='https://dashboard.render.com/template=https://github.com/Kgtech-cmr/KERM-WEB' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-black?style=for-the-badge&logo=render&logoColor=white'/>

#### TERMUX DEPLOY

1. Copy this code to deploy on Termux.
    <br>
```
1.    apt update
2.    apt upgrade
3.    pkg update && pkg upgrade
4.    pkg install bash
5.    pkg install libwebp
6.    pkg install git
7.    pkg install nodejs
8.    pkg install ffmpeg
9.    pkg install wget
10.  pkg install imagemagick
11.  pkg install yarn
12.  termux-setup-storage
13.  cd /storage/emulated/0/techgodv4
14.  yarn install
15   npm start


if you exit termux then again start bot with 2 cmd

1.       cd /storage/emulated/0/techgodv4
2.       npm start
```

  **Do not forget to give a star⭐️ please**

★𝙿𝚘𝚠𝚎𝚛𝚎𝚍 𝚋𝚢 (𝐊𝐆 𝐓𝐄𝐂𝐇)-𝚃𝚎𝚌𝚑-𝚃𝚎𝚊𝚖. ©2024
